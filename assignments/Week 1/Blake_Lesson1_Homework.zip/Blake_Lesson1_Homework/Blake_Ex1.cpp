#include <iostream>
#include <string>
using namespace std;

int main (){


string firstName;
string lastName;

cout << "Input your first name: \n" << endl;
cin >> firstName;
cout << "Input your last name: \n" << endl;
cin >> lastName;

cout << firstName << " " << lastName << "\n" << endl;
cout << firstName << "  " << lastName << "\n" << endl;
cout << firstName << "\n" << lastName << endl;

return 0;
}
